import React from 'react';

const Cart = () => {
  return (
    <div className='content'>
      <h1>Shopping Cart</h1>
      <p>Your selected items will be shown here.</p>
    </div>
  );
};

export default Cart;
