import React from 'react';

const FormLogin = () => {
  return (
    <div className='content'>
      <h1>login</h1>
    </div>
  );
};

export default FormLogin;