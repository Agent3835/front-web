import React from 'react';

const Installations = () => {
  return (
    <div className='content'>
      <h1>Installations</h1>
      <p>Request product installations here.</p>
    </div>
  );
};

export default Installations;
